#include "App.hpp"

int main()
{
    App app = App("estoque.csv");
    return app.run();
}